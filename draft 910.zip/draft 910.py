import re

college_records = []

class gen_info:

    def __init__(self, name, email): 
        self.name = name
        self.email = email


class display_information:

    def repr (self):
        item = {}
        for key in self.__dict__:
            item.update({key: getattr(self,key)})
        return str(item)


class validator():
    def __init__(self):
        bad_characters = ['!', '"', "'", '#', '$',                    #list of prohibited characters for the email
                                '%', '^', '&', '*', '(', 
                                ')', '=', '+', ',', '<', 
                                '>', '/', '?', ';', ':', 
                                '[', ']', '{', '}','\\',
                           ]
        def bad_characters_check(characters_used, bad_characters_used):
             for character in characters_used:
                if character in bad_characters_used:
                    Return = True

        def valid_email():
            while True:
                enter_email = input("Please enter the employees email address: ")
                if re.match('[\S]+[@][\S]+[.]\w{2,3}$', enter_email):
                    if bad_characters_check(enter_email, bad_characters):
                        print("Invalid Email characters found.")
                    else:
                        return enter_email
                else:
                    print("Invalid Email Format")

        def valid_name():
                while True:
                    enter_name = input("Please enter the employees email address: ")
                    if re.match("^[a-zA-Z][a-zA-Z '-]", enter_name):
                        return enter_name
                    else:
                        print("Invaild Name Format")

        def _valid_id():
            if self.__class__.__name__ == 'Student':
                maximum_ID_length = 7
            elif self.__class__.__name__ == 'Instructor':
                maximum_ID_length = 5
            while True:
                enter_id = input("Please enter the employee ID: ")
                if enter_id:
                    try:
                        int(enter_id)                 # The input needs to be digits.
                        if len(enter_id) <= maximum_ID_length:         # The input needs to be less than 7 digits.
                            return enter_id
                              # Break the loop if the input is a number of 7 or less digits long.
                        else:
                            print("The employee ID is too long")
                    except:
                        print("The employee ID is invalid")
                else:
                    exit("You did not enter an employee ID")

               
        self.email = valid_email()
        self.name = valid_name()
        self.ID = _valid_id
#The individual's email address (this is required, and must be primarily comprised of alphanumeric characters. 
# It also cannot contain any of the following characters: ! " ' # $ % ^ & * ( )  = + , < > / ? ; : [ ] { } \ ).

#The individual's name (this is required, and must be primarily comprised of upper- and lower-case letters. 
# It also cannot contain any of the following characters: ! " @ # $ % ^ & * ( ) _ = + , < > / ? ; : [ ] { } \ ).

        
    

#Write your program such that if a user inputs any of the above information incorrectly, 
# the program asks the user to re-enter it before continuing on. Your program should accept any 
# number of individuals until the person using the program says they are done.


class student(display_information, validator, gen_info): 
    def __init__(self):        
        self.role = 'Student'
        validator.__init__(self)  
        self.program_of_study = input('Please enter the program of study: ')                   
   
       
class instructor(display_information, validator, gen_info):
    def __init__(self):                     
        self.role = 'Instructor'
        validator.__init__(self)  
        self. last_institution_they_graduated_from = input('Please enter the name of the last institution the Instructor graduated from: ') 
        self. highest_degree_attained = input('Please enter the highest degree attained by the Instructor: ')

    def collect_ind_info():
        while True:
            user_type = input("Is this a Student or Instructor")
            if user_type == 'Student':
                return student()
            elif user_type == 'Instructor' :
                return instructor()
            else:
                print("Please select Student or Instructor")


def keep_going(collect_ind_info):     
    run_program = True
    while run_program:

        ind = collect_ind_info()

        if ind not in college_records:
            college_records.append(ind)

        run_program = keep_going()

print(college_records)