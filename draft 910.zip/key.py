import re

class DisplayInformation: 
    """
    Provides an inheritable display overload method that shows instances with a name:value pair 
    for each attribute stored on the instance itself.
    """ 
    def __repr__(self):
        item = {}
        for key in self.__dict__:
            item.update({key: getattr(self, key)})
        return str(item)
    
class Validator:
    """
    Provides an inheritable method that validates inputs and passes validated input values to 
    three attributes (ID, name, email) on the instance.
    """
    def __init__(self):  
        bad_characters = ['!', '"', "'", '#', '$',
                          '%', '^', '&', '*', '(', 
                          ')', '=', '+', ',', '<', 
                          '>', '/', '?', ';', ':', 
                          '[', ']', '{', '}', '\\'
                          ]
        def bad_characters_check(passed_characters_entered, passed_bad_characters):
            """Provide a method to check if the characters entered contains any bad characters in the list"""
            for character in passed_characters_entered:
                if character in passed_bad_characters:
                    return True 
                
        def get_valid_email():
            """
            Ask the user for input of email address that needs to match the right format 
            and doesn't contains bad character. The format requirements include: 
            "[\S]+[@][\S]+" means there needs to be one or more characters before and after a "@".
            "[.]\w{2,3}" means to match dot followed by any alphanumeric combination of characters of length 2 or 3.
            "$" means to match the end of the string.
            """ 
            while True:
                email_address_entered = input('Enter email address: ')
                if re.match('[\S]+[@][\S]+[.]\w{2,3}$', email_address_entered):
                    if bad_characters_check(email_address_entered, bad_characters):
                        print('Bad email characters found.')
                    else:
                        return email_address_entered
                else:
                    print('Wrong email format!')
                    
        def get_valid_name():
            """
            Ask the user for input of name which should starts with alphabets and 
            contains only alphabets and spaces and does not contain any bad character.
            """  
            while True:
                name_entered = input('Enter name: ')
                if re.match("^[a-zA-Z][a-zA-Z ]+$", name_entered):
                    if bad_characters_check(name_entered, bad_characters):
                        print('Bad email characters found.')
                    else:
                        return name_entered
                else:
                    print('Invalid characters found.')
                
        def get_valid_ID():
            """
            Ask the user for input of ID. Depending on the role of the individual, the maxium 
            length of ID will be either 5 for student or 7 for instructor.
            """  
            if self.__class__.__name__ == 'Student':
                max_ID_length = 5
            elif self.__class__.__name__ == 'Instructor':
                max_ID_length = 7
            while True:
                ID_entered = input('Enter ID: ')
                if ID_entered: 
                    try:
                        int(ID_entered)       
                        if len(ID_entered) <= max_ID_length:
                            return ID_entered
                        else:
                            print('Your ID is too long.')
                    except:
                        print('You entered an invalid ID!')
                else:
                    print('You did not enter any ID.')
                    
        # Call functions to collect and validate ID, name and email. 
        self.ID = get_valid_ID()
        self.name = get_valid_name()
        self.email = get_valid_email()

class Instructor(Validator, DisplayInformation):
    """
    Create a instructor class which inherits the attributes of ID, name, and email from the validator class.
    It has its own attributes of role, last_graduated_institution, and highest_degree. The role has been set 
    as instructor. Will ask for user's input for the other two. 
    It also inherits the Displayinformation class to gain the __repr__ function for displaying all the attributes 
    and the corresponding values.
    """
    def __init__(self):
        self.role = 'instructor'
        Validator.__init__(self)
        self.last_graduated_institution = input('Enter the name of the last institution they graduated from: ')
        self.highest_degree = input('Enter the highest degree: ')
        
class Student(Validator, DisplayInformation):
    """
    Create a student class which inherits the attributes of ID, name, and email from the validator class. 
    It has its own attributes of role, and program. The role has been set as student. Will ask for user's
    input of program.
    It also inherits the Displayinformation class to gain the __repr__ function for displaying all the attributes 
    and the corresponding values.
    """
    def __init__(self):
        self.role = 'student'
        Validator.__init__(self)
        self.program = input('Enter the program of study: ')
        
def collect_individual_info(): 
    """Provide a function to ask for the user's input of the individual role and return corresponding class""" 
    while True:
        entered_role = input('Is this individual a student or an instructor?') 
        if entered_role == 'student':
            return Student()
        elif entered_role == 'instructor':
            return Instructor()
        else: 
            print('Please enter correct role of the individual.')

def keep_going():
    """Provide a function to ask the user to decide whether to enter more individuals' infomation"""
    keep_going_entered = input('Would you like to enter more? Answer "n" to stop. Press any other key to continue.')
    if keep_going_entered == "n":
        print('Finished entering information.')
        return False
    else:
        print('Please enter more individuals')
        return True

# Run the program.

college_records = []
run_program = True 
while run_program:
    
    # Call the collect_individual_info function to creat either a student or instructor object.
    individual = collect_individual_info()
    
    # Hold the information in a list. Discard if the the same individual is already there.
    if individual not in college_records:
        college_records.append(individual)
        
    # Call the keep_going function
    run_program = keep_going() 
    
# Print out all entries in the college_records list
print(college_records)

