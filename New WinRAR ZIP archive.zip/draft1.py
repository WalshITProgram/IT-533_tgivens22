import re

emp_info = []

run_program = True

while run_program:

    emp_id_ok = False

    while not emp_id_ok:
        emp_id = input("Please enter the employee ID: ")
        if emp_id:
            try:
                int(emp_id)
                if len(emp_id) <= 7:
                    print("Your employee ID is correct")
                    emp_id_ok = True
                else:
                    print("The employee ID is too long")
            except:
                print("The employee ID is invalid")
        else:
            exit("You did not enter an employee ID")
#emp id set to false because the ID has not been accepted yet
#while loop will run until the input is accepted, appending accepted input to temp list
#has to be an interger and seven digits or less, if correct message will appear. if too long else message will appear, if the character is bad excecpt message will appear
# if nothing is entered else message will appear


    valid_name_entered = False
    while not valid_name_entered:
        name = input('Enter name: ')

        if re.match("^[a-zA-Z][a-zA-Z '-]", name):
            valid_name_entered = True
        else:
            print('Invalid characters found.')

#emp name set to false because the ID has not been accepted yet
#while loop will run until the input is accepted, appending accepted input to temp list. When accepted it will be split with a comma
#Looking for bad characters, if a bad character is found name will be rejected. If there are no bad characters found message will print. if too bad character appears a message will appear letting them know it could not be stored
    bad_email_characters = ['!', '"', "'", '#', '$',
                                '%', '^', '&', '*', '(', 
                                ')', '=', '+', ',', '<', 
                                '>', '/', '?', ';', ':', 
                                '[', ']', '{', '}','\\',
                           ]
    emp_email_ok = False
    while not emp_email_ok:
        enter_email = input("Please enter the employees email address: ")
        if re.match('[\S]+[@][\S]+[.]\w{2,3}$', enter_email):
            bad_email_characters_found = False
                        
            for character in bad_email_characters:
                if character in enter_email:
                    bad_email_characters_found = True

            if not bad_email_characters_found:
                emp_email_ok = True
        else:
            print("The employees email address contains unrecognized characters and could not be stored")  
    
#set to false, email has not been entered yet. asking for input, appending to temp list.  If a bad character is found the email address will be rejected.
#If theres is not a bad charter concatenated message will appear, if found else message will appear.

    bad_address_characters = ['"', "'", '@', '$', 
                              '%','^', '&', '*', 
                              '_', '=', '+', '<', 
                              '>', '?', ';',':', 
                              '[', ']', '{', '}'
                             ]

    emp_add_ok = False
    while not emp_add_ok:
        emp_home_add = input("please enter the employees address: ")
        if emp_home_add:
            bad_address_characters_found = False
            
            for character in bad_address_characters:
                if character in emp_home_add:
                    bad_address_characters_found = True

            if not bad_address_characters_found:
                print("the employees address has been stored")
                emp_add_ok = True
        else:
            print("The employees address contains unrecognized characters and could not be stored")
  

#Address not found yet, while loop looking for correct input to append to tmp list. cycling through looking for bad characters, if none found address will be stored, else the message cannot be stored
    emp_sal_ok = False

    while not emp_sal_ok:
        emp_salary = float(input("Please enter the employees salary: "))
        if emp_salary:
            try:
                float(emp_salary)
                if 18 < float(emp_salary) < 27:
                    print("Your employee salary is accepted")
                    emp_sal_ok = True
                else:
                    print("The employee salary is not between 18 and 27")
            except:
                 print("The employee salary is invalid")
        else:
            exit("You did not enter an employee salary")
    
#set to false salary has not been found yet. floating number for salary that must be between 18 to 27, if it meets those criteria it will be accepted.
#If an not floating number is entered except message will appear, if nothing is entered else message will appear. 
   
    emp_info.append({'emp_id': emp_id,
                     'name': name, 'email': enter_email,
                     'emp_address': emp_home_add, 'emp_salary': emp_salary
                })


    enter_more_input = input('Would you like to continue entering employee information? Enter "N" to stop. Press any other key to continue.')
    if enter_more_input == "N":
        print('Thank you for entering the employee info')
        run_program = False
    else:
        print('Please enter employee information')

for employee in emp_info:
    employee.update((key, str(employee[key]) + ' ' + 'IT DEPARTMENT') for key, value in employee.items() if key == "name")
    employee.update((key, float(employee[key]) * 1.3) for key, value in employee.items() if key == "salary")

    print(emp_info)

run_program = False










